public interface Comparable{
    public double getDist();
    public int compare (Comparable other);
} 